// apps/desktop/src/renderer/components/settings/skills/index.ts

export { SkillsPanel } from './SkillsPanel';
export { SkillCard } from './SkillCard';
export { AddSkillDropdown } from './AddSkillDropdown';
