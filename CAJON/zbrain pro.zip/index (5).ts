export { captureForAI, type ScreenshotMetadata } from './screenshots';
