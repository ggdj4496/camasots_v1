export { registerVertexHandlers } from './vertex';
