export { isWaitingForUser } from '@accomplish_ai/agent-core/common';
