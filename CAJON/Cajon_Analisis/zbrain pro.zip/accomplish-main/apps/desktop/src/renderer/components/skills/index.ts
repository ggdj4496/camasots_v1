// apps/desktop/src/renderer/components/skills/index.ts

export { CreateSkillModal } from './CreateSkillModal';
