// apps/desktop/src/main/skills/index.ts

export { SkillsManager, skillsManager } from './SkillsManager';
