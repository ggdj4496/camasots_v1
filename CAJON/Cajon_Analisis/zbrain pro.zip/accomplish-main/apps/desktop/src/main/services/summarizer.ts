/**
 * @deprecated Import from '@accomplish_ai/agent-core' instead.
 * This file re-exports from the core package for backward compatibility.
 */

export { generateTaskSummary, type GetApiKeyFn } from '@accomplish_ai/agent-core';
