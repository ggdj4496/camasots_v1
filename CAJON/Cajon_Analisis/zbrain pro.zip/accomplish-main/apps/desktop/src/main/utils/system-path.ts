// Re-exported from core for better cross-platform support (Windows path delimiters)
export { getExtendedNodePath, findCommandInPath } from '@accomplish_ai/agent-core';
